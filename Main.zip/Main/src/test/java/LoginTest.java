/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.main;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Student
 */




class LoginTest {

    private Login login;

    @BeforeEach
    void setUp() {
        login = new Login(); // create a fresh Login object before each test
    }

    @Test
    void testCheckUserName() {
        assertTrue(login.checkUserName("kyl_1"), "Valid username should pass");
        assertFalse(login.checkUserName("kyle!!!!!!!"), "Username longer than 5 should fail");
        assertFalse(login.checkUserName("kyle"), "Username without underscore should fail");
    }

    @Test
    void testCheckPasswordComplexity() {
        assertTrue(login.checkPasswordComplexity("Ch&&sec@ke99!"), "Valid password should pass");
        assertFalse(login.checkPasswordComplexity("password"), "No capital letter should fail");
        
    }

    @Test
    void testCheckCellPhoneNumber() {
        assertTrue(login.checkCellPhoneNumber("+27838968976"), "Valid SA number should pass");
        assertFalse(login.checkCellPhoneNumber("0838968976"), "Missing +27 should fail");
        
    }

    @Test
    void testRegisterUserSuccess() {
        String message = login.registerUser("kyl_1", "Ch&&sec@ke99!", "+27838968976");
        assertEquals("User registered successfully.", message);
    }

    @Test
    void testLoginUser() {
        login.registerUser("kyl_1", "Ch&&sec@ke99!", "+27838968976");

        // Successful login
        assertTrue(login.loginUser("kyl_1", "Ch&&sec@ke99!"));

        // Failed login
        assertFalse(login.loginUser("kyle!!!!!", "Ch&&sec@ke99!"));
        assertFalse(login.loginUser("kyl_1", "password"));
    }
}
   