/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.main;

/*User input is the process of getting typed in information from 
the end user, to get user input we use "Scanner"
which is a blueprint for creating objects that can read user input
*/
//The first thing we do is Import the Scanner class so we can take input from the user
import java.util.Scanner;



/**
 *
 * @author Student
 */
//Our class name is UserInput
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        //Username Example
        
        //First step: Create scanner object
        Scanner input = new Scanner(System.in);
        
        Login login = new Login();
        
        //We will now ask the user to enter their username
        System.out.println("Enter your username:");
       String username = input.nextLine();
       
       System.out.print("Enter password: ");
       String password = input.nextLine();
       
       System.out.print("Enter your South African phone number (+27...):");
       String phone = input.nextLine();
       
       
       //RegisterUser Method and store message it returns
       String response = login.registerUser(username, password, phone);
       
       
       //Registration message
       System.out.println(response);
       
       
       // --- Login Section
        System.out.println("\n=== User Login");
        
        System.out.print("Enter your username");
        String loginUsername = input.nextLine();
        
        System.out.print("Enter your password");
        String loginPassword = input.nextLine();
        
        
        //LoginUser matches the stored ones
        boolean loggedIn = login.loginUser(loginUsername, loginPassword);
        
        //Printout the correct login in message
        String loginMessage = login.returnLoginStatus(loggedIn);
        
        System.out.println(loginMessage);
    }
    
}

