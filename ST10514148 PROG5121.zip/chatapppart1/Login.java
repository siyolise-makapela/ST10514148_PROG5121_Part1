/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.chatapppart1;
//This will be your package name depending on how you saved your project
//Do NOT delete the package line

/**
 *
 * @author Student
 */
public class Login {
   
    //This is where the username details will be stored
    
   private String username;
   private String password; 
   private String phoneNumber;
    
    //========================================================
   //  Validations using the Boolean methods
   //===============================================================
    
    //You are required to check the following:
    // - Check whether the username contains an underscore
    // - Check whether the username is no more than 5 characters long
    //----------------------------------------------------------------------------------
    public boolean checkUserName(String username)  {
        
        // username must contain an underscore("_")
        // Ensure username length is <=5
        return username.contains("_") && username.length() <=5;

    }
    
           
        
        //=============================================================
        // Password must be at least 8 characters long
        // Password must have a Capital letter
        // Password must at least have one special character
        // Password must have one numeral value
        //----------------------------------------------------------------------------------
        public boolean checkPasswordComplexity(String password)  {
        
        boolean hasCapital = false;
        boolean hasNumber = false;
        boolean hasSpecial = false;
    
       // Loop through each character in the password
       
       for (int i= 0; i < password.length(); i++) {
           char c = password.charAt(i); // get the current character
           
           
           if (Character.isUpperCase(c)) {
               hasCapital = true;  // Capital letter has been found
           }
               
              else if (Character.isDigit(c)){
               hasNumber = true; // Number has been detected
              }
               
               else if (!Character.isLetterOrDigit(c)){
                       hasSpecial = true;
                       }
               
                      }
       
       return password.length() >= 8 && hasCapital && hasNumber && hasSpecial;
        }
          
           //CELLPHONE NUMBER VALIDATION
           public boolean checkCellPhoneNumber(String phone) {
               return phone.startsWith("+27") && phone.length() <= 12;
           }
            public String registerUser(String username, String password, String phoneNumber){
                
                if(!checkUserName(username)){
                return "Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.";
                }
                
                
                if(!checkPasswordComplexity(password)){
                return "Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";
                }
                
                if(!checkCellPhoneNumber(phoneNumber)){
                 return "Cellphone number incorrectly formatted or does not contain international code.";
                }
                
               
                
                this.username = username;
                this.password = password;
                this.phoneNumber = phoneNumber;
                        
               return "User registered successfully.";
            }
            
            public boolean loginUser(String loginUsername, String loginPassword){
                return loginUsername.equals(this.username) && loginPassword.equals(this.password);
                
            }
              
            public String returnLoginStatus(boolean loggedIn){
                if (loggedIn){
                    return "Welcome " + this.username + ", it is great to see you again.";
                } else{
                    return "Username or password incorrecr, please try again.";
                }
            }
    
            
            
               
                
            
           
               
        
          
                
           

           
           
           
           
           
           
           
       
    
       }    
     

