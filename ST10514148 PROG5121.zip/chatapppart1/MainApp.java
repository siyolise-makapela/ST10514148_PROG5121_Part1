/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.chatapppart1;

import java.util.Scanner;

/**
 *
 * @author Student
 */
public class MainApp {
    public static void main(String[] args, String phone){
        
        //Scanner allows users to enter their information
        Scanner input = new Scanner(System.in);
        
       
       //Login class so we can be able to call its methods
       Login login = new Login();
       
       
       //---Registration Section ---
       System.out.println("=== User Registration ===");
       
       System.out.print("Enter a username: ");
       String username = input.nextLine();
       
       System.out.print("Enter a password");
       String password = input.nextLine();
       
       System.out.print("Enter your South African phone number (+27..):");
       
       
       //Call the registerUser method and store the message it returns
       String response  = login.registerUser(username, password, phone);
       
       //Resgistration message will apper below
       System.out.println(response);
       
       // If registration was a success then continue to login
       if (response.equals("User registered successfully.")){
       
       //---Login Section---
       System.out.println("\n=== USER LOGIN ===");
       
       System.out.print("Enter your username");
       String loginUsername = input.nextLine();
       
       System.out.print("Enter your password: ");
       String loginPassword = input.nextLine();
       
       boolean loggedIn = login.loginUser(loginUsername, loginPassword);
       String loginMessage = login.returnLoginStatus(loggedIn);
       System.out.println(loginMessage);
       }
        
input.close();
    }
    

}
   
        
       
       
       
               
    
    

